import sqlite3


conn = sqlite3.connect('base_projet.db')
cur = conn.cursor()

# On crée les tables en lisant le fichier SQL
with open('creation_tables.sql', 'r') as f:
    cur.executescript(f.read())

# On ajoute quelques données pour testercur.execute("INSERT INTO CARBURANT VALUES (1, 'Gazole')")
cur.execute("INSERT INTO STATION VALUES ('93430001', '93430', 'VILLETANEUSE')")

# On enregistre tout
conn.commit()
conn.close()

print("La base est prête et les données sont ajoutées.")