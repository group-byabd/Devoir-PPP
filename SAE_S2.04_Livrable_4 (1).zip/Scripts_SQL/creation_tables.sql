-- Création des tables du projet
CREATE TABLE STATION (
    id_station VARCHAR PRIMARY KEY,
    cp VARCHAR(5),
    ville VARCHAR(100)
);

CREATE TABLE CARBURANT (
    id_carburant INT PRIMARY KEY,
    nom VARCHAR(50)
);

CREATE TABLE PRIX (
    id_station VARCHAR REFERENCES STATION(id_station),
    id_carburant INT REFERENCES CARBURANT(id_carburant),
    date_releve TIMESTAMP,
    prix REAL,
    PRIMARY KEY (id_station, id_carburant, date_releve)
);

CREATE TABLE RUPTURE (
    id_station VARCHAR REFERENCES STATION(id_station),
    id_carburant INT REFERENCES CARBURANT(id_carburant),
    date_debut TIMESTAMP
);