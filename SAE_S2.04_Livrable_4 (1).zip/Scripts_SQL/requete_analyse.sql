
SELECT s.ville, c.nom, p.prix
FROM STATION s
JOIN PRIX p ON s.id_station = p.id_station
JOIN CARBURANT c ON p.id_carburant = c.id_carburant;


SELECT c.nom, AVG(p.prix) as moyenne
FROM PRIX p
JOIN CARBURANT c ON p.id_carburant = c.id_carburant
GROUP BY c.nom;


SELECT s.ville, COUNT(*) as nb_ruptures
FROM RUPTURE r
JOIN STATION s ON r.id_station = s.id_station
GROUP BY s.ville;