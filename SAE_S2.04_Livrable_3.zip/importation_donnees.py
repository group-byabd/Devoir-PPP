import sqlite3

print("Lancement du script d'importation")

connexion = sqlite3.connect('ma_base_carburants.db')
curseur = connexion.cursor()
print("Connexion réussie.")

with open('creation_et_requetes.sql', 'r', encoding='utf-8') as fichier:
    script_sql = fichier.read()
    curseur.executescript(script_sql)
    print("Tables créées avec succès.")

liste_carburants = [
    (1, 'Gazole'),
    (2, 'SP95'),
    (3, 'E10'),
    (4, 'SP98'),
    (5, 'GPLC'),
    (6, 'GNV')
]

print("Insertion des carburants...")
for carburant in liste_carburants:
    curseur.execute("INSERT INTO CARBURANT (id_carburant, nom_carburant) VALUES (?, ?)", (carburant[0], carburant[1]))

liste_stations = [
    ('93430001', 48.956, 2.421, '93430', 'Avenue Jean Jaures', 'VILLETANEUSE'),
    ('75015002', 48.841, 2.292, '75015', 'Rue de Vaugirard', 'PARIS')
]

print("Insertion des stations...")
for station in liste_stations:
    curseur.execute("INSERT INTO STATION (id_station, latitude, longitude, cp, adresse, ville) VALUES (?, ?, ?, ?, ?, ?)", station)

connexion.commit()
connexion.close()

print("Fin de l'importation. La base est prête !")
