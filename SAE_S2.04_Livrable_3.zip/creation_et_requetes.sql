-- Suppression des tables si elles existent pour réinitialiser la base
DROP TABLE IF EXISTS RUPTURE;
DROP TABLE IF EXISTS PRIX;
DROP TABLE IF EXISTS HORAIRE;
DROP TABLE IF EXISTS PROPOSER_SERVICE;
DROP TABLE IF EXISTS SERVICE;
DROP TABLE IF EXISTS CARBURANT;
DROP TABLE IF EXISTS STATION;

-- Création de la table STATION
CREATE TABLE STATION (
    id_station VARCHAR PRIMARY KEY,
    latitude NUMERIC,
    longitude NUMERIC,
    cp VARCHAR,
    adresse VARCHAR,
    ville VARCHAR
);

-- Création de la table CARBURANT
CREATE TABLE CARBURANT (
    id_carburant INT PRIMARY KEY,
    nom_carburant VARCHAR NOT NULL
);

-- Création de la table SERVICE
CREATE TABLE SERVICE (
    id_service INT PRIMARY KEY,
    nom_service VARCHAR NOT NULL
);

-- Création de la table PROPOSER_SERVICE
CREATE TABLE PROPOSER_SERVICE (
    id_station VARCHAR REFERENCES STATION(id_station),
    id_service INT REFERENCES SERVICE(id_service),
    PRIMARY KEY (id_station, id_service)
);

-- Création de la table HORAIRE
CREATE TABLE HORAIRE (
    id_horaire INT PRIMARY KEY,
    id_station VARCHAR REFERENCES STATION(id_station),
    jour_semaine INT,
    heure_ouverture TIME,
    heure_fermeture TIME
);

-- Création de la table PRIX
CREATE TABLE PRIX (
    id_station VARCHAR REFERENCES STATION(id_station),
    id_carburant INT REFERENCES CARBURANT(id_carburant),
    date_releve TIMESTAMP,
    valeur NUMERIC(4,3),
    PRIMARY KEY (id_station, id_carburant, date_releve)
);

-- Création de la table RUPTURE
CREATE TABLE RUPTURE (
    id_station VARCHAR REFERENCES STATION(id_station),
    id_carburant INT REFERENCES CARBURANT(id_carburant),
    date_debut TIMESTAMP,
    date_fin TIMESTAMP,
    type_rupture VARCHAR,
    PRIMARY KEY (id_station, id_carburant, date_debut)
);

-- Requête A : Voir toutes les stations et leurs carburants
SELECT DISTINCT s.id_station, s.ville, s.adresse, c.nom_carburant
FROM STATION s
JOIN PRIX p ON s.id_station = p.id_station
JOIN CARBURANT c ON p.id_carburant = c.id_carburant
ORDER BY s.ville, s.id_station;

-- Requête B : Comparer le prix du Gazole à Paris
SELECT s.id_station, s.adresse, p.valeur AS prix_gazole, p.date_releve
FROM STATION s
JOIN PRIX p ON s.id_station = p.id_station
JOIN CARBURANT c ON p.id_carburant = c.id_carburant
WHERE c.nom_carburant = 'Gazole' AND s.ville = 'PARIS'
ORDER BY p.valeur ASC;

-- Requête C : Trouver les 5 stations les moins chères pour le SP95
SELECT s.id_station, s.ville, s.adresse, p.valeur AS prix_sp95
FROM STATION s
JOIN PRIX p ON s.id_station = p.id_station
JOIN CARBURANT c ON p.id_carburant = c.id_carburant
WHERE c.nom_carburant = 'SP95'
AND p.date_releve = (
    SELECT MAX(date_releve)
    FROM PRIX
    WHERE id_carburant = c.id_carburant AND id_station = s.id_station
)
ORDER BY p.valeur ASC
LIMIT 5;

-- Requête D : Compter les ruptures de stock
SELECT s.ville, c.nom_carburant, COUNT(r.date_debut) AS nombre_total_ruptures
FROM STATION s
JOIN RUPTURE r ON s.id_station = r.id_station
JOIN CARBURANT c ON r.id_carburant = c.id_carburant
GROUP BY s.ville, c.nom_carburant
ORDER BY nombre_total_ruptures DESC;

-- Requête E : Filtrer les stations ouvertes le dimanche
SELECT s.id_station, s.ville, s.adresse, h.heure_ouverture, h.heure_fermeture
FROM STATION s
JOIN HORAIRE h ON s.id_station = h.id_station
WHERE h.jour_semaine = 7
ORDER BY s.ville;

-- Requête F : Résumé national des prix
SELECT c.nom_carburant,
       COUNT(DISTINCT p.id_station) AS stations_actives,
       MIN(p.valeur) AS prix_minimum,
       MAX(p.valeur) AS prix_maximum,
       ROUND(AVG(p.valeur), 3) AS prix_moyen_calcule
FROM PRIX p
JOIN CARBURANT c ON p.id_carburant = c.id_carburant
GROUP BY c.nom_carburant
ORDER BY prix_moyen_calcule DESC;
